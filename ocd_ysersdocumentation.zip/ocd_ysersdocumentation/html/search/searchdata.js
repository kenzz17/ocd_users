var indexSectionsWithContent =
{
  0: "cfglmpru",
  1: "cflmpru",
  2: "cgp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

