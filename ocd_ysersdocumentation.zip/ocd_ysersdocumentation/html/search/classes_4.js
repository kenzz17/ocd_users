var searchData=
[
  ['project',['Project',['../classustore_1_1models_1_1Project.html',1,'ustore::models']]],
  ['projectacessview',['ProjectAcessView',['../classustore_1_1views_1_1ProjectAcessView.html',1,'ustore::views']]],
  ['projectdeleteview',['ProjectDeleteView',['../classustore_1_1views_1_1ProjectDeleteView.html',1,'ustore::views']]],
  ['projectfilegetterserializer',['ProjectFileGetterSerializer',['../classustore_1_1serializers_1_1ProjectFileGetterSerializer.html',1,'ustore::serializers']]],
  ['projectgetview',['ProjectgetView',['../classustore_1_1views_1_1ProjectgetView.html',1,'ustore::views']]],
  ['projectserializer',['ProjectSerializer',['../classustore_1_1serializers_1_1ProjectSerializer.html',1,'ustore::serializers']]]
];
