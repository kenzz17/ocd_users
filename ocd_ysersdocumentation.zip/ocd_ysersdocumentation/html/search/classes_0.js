var searchData=
[
  ['changepasswordserializer',['ChangePasswordSerializer',['../classustore_1_1serializers_1_1ChangePasswordSerializer.html',1,'ustore::serializers']]],
  ['changepasswordview',['ChangePasswordView',['../classustore_1_1views_1_1ChangePasswordView.html',1,'ustore::views']]]
];
