var searchData=
[
  ['meta',['Meta',['../classustore_1_1serializers_1_1UserSerializer_1_1Meta.html',1,'ustore.serializers.UserSerializer.Meta'],['../classustore_1_1serializers_1_1RegisterSerializer_1_1Meta.html',1,'ustore.serializers.RegisterSerializer.Meta']]]
];
