var searchData=
[
  ['registerapi',['RegisterAPI',['../classustore_1_1views_1_1RegisterAPI.html',1,'ustore::views']]],
  ['registerserializer',['RegisterSerializer',['../classustore_1_1serializers_1_1RegisterSerializer.html',1,'ustore::serializers']]]
];
