var searchData=
[
  ['loginapi',['LoginAPI',['../classustore_1_1views_1_1LoginAPI.html',1,'ustore::views']]]
];
