var searchData=
[
  ['create',['create',['../classustore_1_1serializers_1_1RegisterSerializer.html#ac0cc59ea0aa5b2cf196b4e434fa3cc4e',1,'ustore::serializers::RegisterSerializer']]]
];
